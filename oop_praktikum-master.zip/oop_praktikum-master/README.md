# oop_praktikum
informatika 6 grupa

how to get repo:
git clone https://github.com/mvatanasovFMI/oop_praktikum.git
git config user.email "email@example.com"
git config user.name "name"

how to create your branch:
cd git/oop_praktikum
//create your folder(folder name)
//create folder with lesson number
git checkout -b "yourname"


how to commit your changes: 
git add -A //add to stage
git commit -m "some message"

to put in origin:
git push origin "yourname"

